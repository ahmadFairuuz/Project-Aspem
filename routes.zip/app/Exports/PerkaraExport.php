<?php

namespace App\Exports;

use App\Models\Perkara;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;

class PerkaraExport implements FromCollection, WithHeadings
{
    public function collection()
{
    return Perkara::select(
        'register_perkara',
        'tanggal_input',
        'satuan_kerja',
        'jaksa',
        'pasal_dakwaan',
        'pasal_terbukti',
        'status',
        'nama_terpidana',
        'barang_bukti',
        'keterangan_barang_bukti',
        'jenis_perkara',
        'status_perkara',
        'no_putusan_inkraft'
    )->get();
}


    public function headings(): array
{
    return [
        'Register Perkara',
        'Tanggal Input',
        'Satuan Kerja',
        'Jaksa',
        'Pasal Dakwaan',
        'Pasal Terbukti',
        'Status',
        'Nama Terpidana',
        'Barang Bukti',
        'Keterangan Barang Bukti',
        'Jenis Perkara',
        'Status Perkara',
        'No Putusan Inkraft',
    ];
}

}
